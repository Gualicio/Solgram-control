<?php
/**
 * SISTEMA DE GESTIÓN DE OBRAS - SOLGRAM CONTROL
 * -------------------------------------------------------------
 * SCRIPT PHP DE PROCESAMIENTO Y ARCHIVADO DE REPORTES EN LOTES
 * DE EXACTAMENTE 7 DÍAS EN GOOGLE DRIVE Y ENLACE DE FOTOGRAFÍAS.
 * 
 * Desarrollado por un experto en Backend, SQL y APIs de Google.
 * -------------------------------------------------------------
 * 
 * --- ESTRUCTURA SQL RECOMENDADA ---
 * 
 * CREATE TABLE IF NOT EXISTS carpetas_reportes (
 *     id INT AUTO_INCREMENT PRIMARY KEY,
 *     folder_drive_id VARCHAR(255) NOT NULL,
 *     nombre_carpeta VARCHAR(100) NOT NULL,
 *     fecha_inicio DATE NOT NULL,
 *     cantidad_reportes INT DEFAULT 0,
 *     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 * ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 * 
 * CREATE TABLE IF NOT EXISTS reportes_diarios (
 *     id INT AUTO_INCREMENT PRIMARY KEY,
 *     fecha_reporte DATE NOT NULL,
 *     supervisor VARCHAR(150) NOT NULL,
 *     wbs_id VARCHAR(100) NOT NULL,
 *     comentarios TEXT,
 *     carpeta_reporte_id INT DEFAULT NULL,
 *     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 *     FOREIGN KEY (carpeta_reporte_id) REFERENCES carpetas_reportes(id) ON DELETE SET NULL
 * ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 */

// Dependencias requeridas (Cargar librería oficial de Google a través de Composer)
require_once __DIR__ . '/vendor/autoload.php';

// Cabeceras HTTP para responder en formato JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Configuración de Conexión a Base de Datos SQL
define('DB_HOST', 'localhost');
define('DB_USER', 'tu_usuario_sql');
define('DB_PASS', 'tu_contrasena_sql');
define('DB_NAME', 'tu_base_datos_solgram');

// Ruta al archivo JSON de credenciales de Cuenta de Servicio Google
define('GOOGLE_SERVICE_ACCOUNT_JSON', __DIR__ . '/service-account-credentials.json');

try {
    // 1. Inicialización de la Conexión PDO (Base de Datos)
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    // 2. Lectura y parsing de la solicitud JSON enviada por la aplicación cliente
    $rawInput = file_get_contents('php://input');
    $inputData = json_decode($rawInput, true);

    if (empty($inputData)) {
        throw new Exception("Datos de entrada vacíos o JSON mal formado.");
    }

    // Datos obligatorios para el reporte diario
    $date = $inputData['date'] ?? date('Y-m-d');
    $supervisor = $inputData['supervisor'] ?? '';
    $primaryWbsId = $inputData['primaryWbsId'] ?? '';
    $comments = $inputData['comments'] ?? '';
    $images = $inputData['images'] ?? []; // Array de strings Base64
    $labors = $inputData['labors'] ?? []; // Detalles de tareas/mano de obra

    if (empty($supervisor) || empty($primaryWbsId)) {
        throw new Exception("Faltan parámetros críticos (supervisor, primaryWbsId).");
    }

    // 3. Inicialización de los Clientes de Google API (Drive)
    if (!file_exists(GOOGLE_SERVICE_ACCOUNT_JSON)) {
        throw new Exception("El archivo de credenciales de Cuenta de Servicio no se encuentra en la ruta especificada.");
    }

    $googleClient = new Google\Client();
    $googleClient->setAuthConfig(GOOGLE_SERVICE_ACCOUNT_JSON);
    $googleClient->addScope(Google\Service\Drive::DRIVE);

    $driveService = new Google\Service\Drive($googleClient);

    // 4. LÓGICA DE DETECCION Y ENRUTAMIENTO DE CARPETAS (CONDICIÓN A y CONDICIÓN B)
    $pdo->beginTransaction();

    // Consultamos la última carpeta creada en la base de datos SQL
    $stmt = $pdo->query("SELECT * FROM carpetas_reportes ORDER BY id DESC LIMIT 1");
    $lastFolder = $stmt->fetch();

    $folderId = null;
    $dbFolderRecordId = null;
    $shouldCreateNewFolder = false;

    if (!$lastFolder) {
        // No existe ninguna carpeta en el historial (Primer reporte de la historia)
        $shouldCreateNewFolder = true;
    } else {
        $cantidadActual = (int)$lastFolder['cantidad_reportes'];
        if ($cantidadActual >= 7) {
            // Condición A: La carpeta actual ya completó los 7 reportes diarios correspondientes
            $shouldCreateNewFolder = true;
        } else {
            // Condición B: La última carpeta tiene espacio (< 7 reportes)
            $folderId = $lastFolder['folder_drive_id'];
            $dbFolderRecordId = (int)$lastFolder['id'];
            
            // Incrementamos el contador de la carpeta actual en +1
            $updateStmt = $pdo->prepare("UPDATE carpetas_reportes SET cantidad_reportes = cantidad_reportes + 1 WHERE id = ?");
            $updateStmt->execute([$dbFolderRecordId]);
        }
    }

    if ($shouldCreateNewFolder) {
        // Lote Nuevo: Generamos el nombre para la nueva carpeta de Drive
        $folderName = "Lote_Reportes_" . $date;
        
        // Creación del contenedor carpeta física en Google Drive llamando a la API
        $folderMetadata = new Google\Service\Drive\DriveFile([
            'name' => $folderName,
            'mimeType' => 'application/vnd.google-apps.folder',
            // Opcional: Puedes definir una carpeta raíz común para que no queden flotando en Drive
            // 'parents' => ['ID_DE_CARPETA_RAIZ_OPCIONAL']
        ]);

        $driveFolder = $driveService->files->create($folderMetadata, [
            'fields' => 'id'
        ]);

        $folderId = $driveFolder->id;

        // Registramos la nueva carpeta en nuestra base de datos con contador inicializado en 1
        $insertFolderStmt = $pdo->prepare("
            INSERT INTO carpetas_reportes (folder_drive_id, nombre_carpeta, fecha_inicio, cantidad_reportes) 
            VALUES (?, ?, ?, 1)
        ");
        $insertFolderStmt->execute([$folderId, $folderName, $date]);
        $dbFolderRecordId = (int)$pdo->lastInsertId();
    }

    // 5. PROCESAMIENTO Y CARGA DE REGISTRO FOTOGRÁFICO EN LATENCIA DRIVE
    $uploadedPhotosDriveIds = [];

    foreach ($images as $index => $base64Image) {
        // Sanitizar base64 para decodificación binaria
        if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
            $base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
            $imageType = strtolower($type[1]); // png, jpeg, etc.
        } else {
            $imageType = 'jpg'; // Fallback por defecto
        }

        $binaryData = base64_decode($base64Image);
        if ($binaryData === false) {
            continue; // Saltar si hay error en decodificación
        }

        // Metadatos de la imagen individual
        $photoName = "Foto_" . ($index + 1) . "_" . $date . "." . $imageType;
        $photoMetadata = new Google\Service\Drive\DriveFile([
            'name' => $photoName,
            'parents' => [$folderId]
        ]);

        $driveServicePhoto = $driveService->files->create(
            $photoMetadata,
            [
                'data' => $binaryData,
                'mimeType' => 'image/' . $imageType,
                'uploadType' => 'media',
                'fields' => 'id'
            ]
        );

        $uploadedPhotosDriveIds[] = [
            'name' => $photoName,
            'drive_id' => $driveServicePhoto->id
        ];
    }

    // 6. PERSISTIR EL REGISTRO DE REPORTE DIARIO EN LA BASE DE DATOS LOCAL (Sin Google Sheets)
    $insertReportStmt = $pdo->prepare("
        INSERT INTO reportes_diarios (fecha_reporte, supervisor, wbs_id, comentarios, carpeta_reporte_id) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $insertReportStmt->execute([
        $date,
        $supervisor,
        $primaryWbsId,
        $comments,
        $dbFolderRecordId
    ]);

    // Consolidar todos los cambios en la transacción atómica
    $pdo->commit();

    // Retornamos respuesta JSON de éxito rotundo a la app cliente
    echo json_encode([
        'status' => 'success',
        'message' => 'Reporte diario procesado exitosamente en Google Drive.',
        'metadata' => [
            'folder_batch_drive_id' => $folderId,
            'folder_record_sql_id' => $dbFolderRecordId,
            'photos_uploaded_count' => count($uploadedPhotosDriveIds),
            'photos_details' => $uploadedPhotosDriveIds
        ]
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    // Reversar cambios en la base de datos si ocurre un error inesperado
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Ocurrió un error en el procesamiento: ' . $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
