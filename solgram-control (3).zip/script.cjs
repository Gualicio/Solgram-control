const fs = require('fs');
let content = fs.readFileSync('src/modules/GanttViewer.tsx', 'utf8');

const map = {
  // Line 313
  'className="flex items-center justify-center text-[10px] font-bold border-r border-[#1f2a44] uppercase bg-[#142042]"':
  'className={cn("flex items-center justify-center text-[10px] font-bold border-r uppercase", state.theme === \'dark\' ? "bg-[#142042] border-[#1f2a44]" : "bg-blue-50 border-blue-200")}',

  // Line 325
  'className="flex items-center justify-center text-[9px] border-r border-[#1f2a44] text-[#7d8590]"':
  'className={cn("flex items-center justify-center text-[9px] border-r", state.theme === \'dark\' ? "border-[#1f2a44] text-[#7d8590]" : "border-gray-200 text-gray-500")}',

  // Line 350
  '"grid grid-cols-[1fr_60px_85px_85px] items-center py-2 px-4 border-b border-[#161b22] hover:bg-[#161b22] cursor-pointer group transition-colors",':
  '"grid grid-cols-[1fr_60px_85px_85px] items-center py-2 px-4 border-b cursor-pointer group transition-colors", state.theme === \'dark\' ? "border-[#161b22] hover:bg-[#161b22]" : "border-gray-200 hover:bg-gray-100",',

  // Line 351
  'level === 0 && "bg-[#1a2230] border-l-4 border-[#ffb703] font-bold"':
  'level === 0 && (state.theme === \'dark\' ? "bg-[#1a2230] border-l-4 border-[#ffb703] font-bold" : "bg-gray-200 border-l-4 border-orange-400 font-bold")',

  // Line 352
  'level === 1 && "bg-[#141a23] border-l-4 border-blue-500"':
  'level === 1 && (state.theme === \'dark\' ? "bg-[#141a23] border-l-4 border-blue-500" : "bg-gray-100 border-l-4 border-blue-500")',

  // Line 386
  '"grid grid-cols-[1fr_60px_85px_85px] items-center py-1.5 px-4 border-b border-[#161b22] hover:bg-[#161b22] cursor-pointer group transition-colors"':
  '"grid grid-cols-[1fr_60px_85px_85px] items-center py-1.5 px-4 border-b cursor-pointer group transition-colors", state.theme === \'dark\' ? "border-[#161b22] hover:bg-[#161b22]" : "border-gray-200 hover:bg-gray-50"',

  // Line 392
  '<div className="flex items-center gap-2 overflow-hidden text-[#b8c2cc]">' :
  '<div className={cn("flex items-center gap-2 overflow-hidden", state.theme === \'dark\' ? "text-[#b8c2cc]" : "text-gray-700")}>',

  // Line 443
  '"h-[31px] border-b border-[#161b22] relative"':
  '"h-[31px] border-b relative", state.theme === \'dark\' ? "border-[#161b22]" : "border-gray-200"',

  // Line 444
  'level === 0 && "bg-[#1a2230]/30 h-[37px] border-b-[#2a3343]"':
  'level === 0 && (state.theme === \'dark\' ? "bg-[#1a2230]/30 h-[37px] border-b-[#2a3343]" : "bg-gray-50 h-[37px] border-b-gray-300")',

  // Line 445
  'level === 1 && "bg-[#141a23]/30"':
  'level === 1 && (state.theme === \'dark\' ? "bg-[#141a23]/30" : "bg-white")',

  // Line 484
  '<div key={`g-t-${task.id}`} className="h-[26px] border-b border-[#161b22] relative">':
  '<div key={`g-t-${task.id}`} className={cn("h-[26px] border-b relative", state.theme === \'dark\' ? "border-[#161b22]" : "border-gray-200")}>',

  // Line 534
  '<div className="p-3 border-r border-[#1f2a44] flex flex-col justify-center">':
  '<div className={cn("p-3 border-r flex flex-col justify-center", state.theme === \'dark\' ? "border-[#1f2a44]" : "border-gray-200")}>',
  
  '<div className="p-3 border-r border-[#1f2a44] flex flex-col justify-center col-span-2">':
  '<div className={cn("p-3 border-r flex flex-col justify-center col-span-2", state.theme === \'dark\' ? "border-[#1f2a44]" : "border-gray-200")}>',

  '<div className="flex items-center gap-6 px-6 py-2 border-b border-[#1f2a44] overflow-x-auto text-xs whitespace-nowrap scrollbar-hide">':
  '<div className={cn("flex items-center gap-6 px-6 py-2 border-b overflow-x-auto text-xs whitespace-nowrap scrollbar-hide", state.theme === \'dark\' ? "border-[#1f2a44]" : "border-gray-200")}>',

  // input bg
  'className="bg-[#1a2440] border border-[#1f2a44] rounded px-8 py-1.5 w-40 focus:outline-none focus:border-blue-500"':
  'className={cn("border rounded px-8 py-1.5 w-40 focus:outline-none focus:border-blue-500", state.theme === \'dark\' ? "bg-[#1a2440] border-[#1f2a44]" : "bg-white border-gray-300")}',

  'className="flex bg-[#1a2440] border border-[#1f2a44] rounded overflow-hidden"':
  'className={cn("flex border rounded overflow-hidden", state.theme === \'dark\' ? "bg-[#1a2440] border-[#1f2a44]" : "bg-white border-gray-300")}',

  'className="px-4 py-1.5 bg-[#1a2440] border border-[#1f2a44] rounded hover:bg-[#23315a] transition-colors"':
  'className={cn("px-4 py-1.5 border rounded transition-colors", state.theme === \'dark\' ? "bg-[#1a2440] border-[#1f2a44] hover:bg-[#23315a]" : "bg-white border-gray-300 hover:bg-gray-50")}',

  'className={cn("flex flex-col overflow-hidden bg-[#0a0e14] transition-all", isTaskPanelHidden ? "w-0 opacity-0" : "opacity-100")}':
  'className={cn("flex flex-col overflow-hidden transition-all", isTaskPanelHidden ? "w-0 opacity-0" : "opacity-100", state.theme === \'dark\' ? "bg-[#0a0e14]" : "bg-white")}',

  'className="grid grid-cols-[1fr_60px_85px_85px] h-[40px] items-center px-4 bg-[#11151c] border-b border-[#1f2a44] text-[9px] font-black text-gray-500 uppercase tracking-widest"':
  'className={cn("grid grid-cols-[1fr_60px_85px_85px] h-[40px] items-center px-4 border-b text-[9px] font-black text-gray-500 uppercase tracking-widest", state.theme === \'dark\' ? "bg-[#11151c] border-[#1f2a44]" : "bg-gray-100 border-gray-200")}',

  '"w-1 bg-[#1f2a44] cursor-col-resize hover:bg-blue-500 transition-colors z-10"':
  '"w-1 cursor-col-resize hover:bg-blue-500 transition-colors z-10", state.theme === \'dark\' ? "bg-[#1f2a44]" : "bg-gray-300"',

  'className="flex-1 flex flex-col overflow-hidden bg-[#0a0e14]"':
  'className={cn("flex-1 flex flex-col overflow-hidden", state.theme === \'dark\' ? "bg-[#0a0e14]" : "bg-white")}',

  'className="h-[40px] border-b border-[#1f2a44] bg-[#11151c] overflow-hidden"':
  'className={cn("h-[40px] border-b overflow-hidden", state.theme === \'dark\' ? "border-[#1f2a44] bg-[#11151c]" : "border-gray-200 bg-gray-100")}',

  'className="flex h-5 border-b border-[#1f2a44]"':
  'className={cn("flex h-5 border-b", state.theme === \'dark\' ? "border-[#1f2a44]" : "border-gray-200")}',

  // Line ~730
  'className="flex justify-between items-center p-6 border-b border-[#30363d]/30"':
  'className={cn("flex justify-between items-center p-6 border-b", state.theme === \'dark\' ? "border-[#30363d]/30" : "border-gray-200")}',

  // Line ~817
  'className="px-6 py-3.5 bg-[#1a2333]/80 border border-blue-500/10 rounded-2xl flex items-center gap-4 transition-all hover:border-blue-500/40 hover:bg-[#1a2333] group backdrop-blur-md shadow-xl"':
  'className={cn("px-6 py-3.5 border rounded-2xl flex items-center gap-4 transition-all group backdrop-blur-md shadow-xl", state.theme === \'dark\' ? "bg-[#1a2333]/80 border-blue-500/10 hover:border-blue-500/40 hover:bg-[#1a2333]" : "bg-white border-blue-100 hover:border-blue-300 hover:bg-blue-50")}',
  
  // Line ~833
  'className="p-6 border-t border-[#30363d]/30 flex justify-end"':
  'className={cn("p-6 border-t flex justify-end", state.theme === \'dark\' ? "border-[#30363d]/30" : "border-gray-200")}',
};

for (const [key, value] of Object.entries(map)) {
  const parts = content.split(key);
  if (parts.length > 1) {
    content = parts.join(value);
  }
}

fs.writeFileSync('src/modules/GanttViewer.tsx', content);
console.log("Replaced entries");

