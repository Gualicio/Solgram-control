import 'dotenv/config'; console.log("Key:", process.env.GEMINI_API_KEY ? "EXISTS" : "MISSING");
