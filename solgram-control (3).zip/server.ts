import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from 'dotenv';
import fs from 'fs';

dotenv.config({ override: true });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ limit: '10mb', extended: true }));

  const DB_PATH = path.join(process.cwd(), 'db.json');

  // Load initial data if exists
  const loadState = () => {
    if (fs.existsSync(DB_PATH)) {
      try {
        const data = fs.readFileSync(DB_PATH, 'utf8');
        return JSON.parse(data);
      } catch (e) {
        console.error("Error reading db.json", e);
        return null;
      }
    }
    return null;
  };

  // API to get shared state
  app.get("/api/state", (req, res) => {
    const state = loadState();
    res.json(state || {});
  });

  // API to update shared state
  app.post("/api/state", (req, res) => {
    try {
      const newState = req.body;
      fs.writeFileSync(DB_PATH, JSON.stringify(newState, null, 2), 'utf8');
      res.json({ success: true });
    } catch (e) {
      console.error("Error saving state", e);
      res.status(500).json({ error: "No se pudo guardar la información en el servidor" });
    }
  });

  // API route for Solgramia Chatbot
  app.post("/api/chat", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY no está configurada. Por favor, selecciona una en Ajustes > Secretos.");
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const { message, chatHistory, appStateContext } = req.body;

      const systemInstruction = `Eres 'Solgramia', un asistente experto en gestión de proyectos de construcción y minería.
Tu objetivo es analizar los datos del proyecto proporcionados y responder consultas sobre:
1. Carta Gantt (Cronograma): Fechas, duraciones, estados de tareas.
2. Control de Personal: Trabajadores en turno, asistencia, cargos.
3. Reportabilidad: Avances diarios, HH (Horas Hombre) reportadas, desviaciones.

REGLAS CRÍTICAS:
- Responde siempre en ESPAÑOL.
- Sé conciso, profesional y basado estrictamente en los datos del contexto proporcionado.
- Si no encuentras un dato específico, indícalo cortésmente.
- Los 'dailyReports' son la fuente de la verdad para el avance real.
- LÓGICA DE TURNOS (14x14): El app proporciona un 'shiftConfig' con 'anchorDate' (fecha inicio) y 'anchorShift' (quien inicia). La rotación es de 14 días. 
  Si anchorShift es 'A', el Grupo A trabaja los primeros 14 días desde anchorDate, mientras B descansa. Luego B trabaja 14 días y A descansa. 
  Calcula esto para cualquier fecha preguntada.

CONTEXTO ACTUAL DEL PROYECTO (JSON):
${JSON.stringify(appStateContext)}`;

      // Update: The ai.chats.create can take history.
      const history = (chatHistory || []).map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.message }]
      }));

      const chatWithHistory = ai.chats.create({
        model: "gemini-3.5-flash",
        config: {
          systemInstruction,
        },
        history: history
      });

      const response = await chatWithHistory.sendMessage({ message });
      
      if (!response.text) {
        throw new Error("La IA no devolvió texto.");
      }

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Chat Error Details:", error);
      let errorMessage = error?.message || "Error al procesar el chat con Solgramia";
      if (typeof errorMessage === 'string' && (errorMessage.includes("API key not valid") || errorMessage.includes("API_KEY_INVALID"))) {
          errorMessage = "La API Key de Gemini es inválida. Por favor, actualízala en Ajustes > Secretos del entorno.";
      }
      res.status(500).json({ error: errorMessage });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
